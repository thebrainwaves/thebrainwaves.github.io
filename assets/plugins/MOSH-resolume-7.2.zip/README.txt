MOSH for Resolume 7.2.1
=======================

64-bit FreeFrameGL effect, FFGL API 2.1. Built for Resolume Arena and Avenue
7.0.3 through 7.2.x. It will not load in Arena 6, and it is not the 7.3+ SDK.


INSTALL
-------

Copy MOSH.dll into the Extra Effects folder and restart Resolume:

    Documents\Resolume Arena\Extra Effects\

Avenue uses Documents\Resolume Avenue\Extra Effects\ instead. If 7.2.1 keeps
a versioned Documents folder, use that one.

The effect is named MOSH. Drop it on a clip.


PARAMETERS
----------

Parameter   Range           Default
---------   -------------   -------
Feed        0.010 - 0.090   0.0545
Kill        0.040 - 0.075   0.062
Rate        1 - 16          8
Size        0.70 - 1.80     1.00
Vectors     0 - 4           1.40
Blocks      4 - 64          12
Hold        1 - 90          16
Split       0 - 16          1
Crush       0 - 16          0
Stain       0 - 100%        35%
Mix         0 - 100%        100%
Reseed      button          off

Feed and Kill are the Gray-Scott pattern. The default is coral.
Stain mixes the clip into the reaction.
Mix is the dry/wet of the finished datamosh.
Reseed's rising edge plants a new field.


Brainhertz Productions - https://brainhertzproductions.com
